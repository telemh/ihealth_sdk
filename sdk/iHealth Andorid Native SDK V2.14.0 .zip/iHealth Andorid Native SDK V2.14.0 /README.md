## iHealth-android-sdk-docs

Demo Link: https://github.com/iHealthLab/iHealth-android-sdk-example
Doc Link: https://chenxuewei-ihealth.github.io/ihealthlabs-sdk-docs

For all the devices supported by the SDK and the API descriptions used by all iHealth devices, you can view them from the link below.
