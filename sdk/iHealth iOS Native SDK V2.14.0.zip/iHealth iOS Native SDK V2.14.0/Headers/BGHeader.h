//
//  BGHeader.h
//  BGDemoCode
//
//  Created by zhiwei jing on 14-6-30.
//  Copyright (c) 2014年 zhiwei jing. All rights reserved.
//

#ifndef BGDemoCode_BGHeader_h
#define BGDemoCode_BGHeader_h

#import "BG1.h"
#import "BG1Controller.h"
#import "BGMacroFile.h"
#import "BG5.h"
#import "BG5Controller.h"
#import "BG5S.h"
#import "BG5SController.h"
#import "BG1S.h"
#import "BG1SController.h"
#import "BG1A.h"
#import "BG1AController.h"
#import "BG5A.h"
#import "BG5AController.h"
#endif
