//
//  NT13BHeader.h
//  iHealthSDKStatic
//
//  Created by user on 2019/9/20.
//  Copyright © 2019 ihealthSDK. All rights reserved.
//

#ifndef NT13BHeader_h
#define NT13BHeader_h

#import "NT13B.h"
#import "NT13BController.h"
#import "NT13BMacroFile.h"

#endif /* NT13BHeader_h */
