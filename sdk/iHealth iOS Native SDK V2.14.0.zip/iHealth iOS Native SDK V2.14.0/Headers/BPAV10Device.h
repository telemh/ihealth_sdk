//
//  BPAV10Device.h
//  iHealthSDKStatic
//
//  Created by Realank on 2017/7/24.
//  Copyright © 2017年 ihealthSDK. All rights reserved.
//

#import "BPBTLEDevice.h"
/**
 a subclass of BPBTLEDevice, which represent BP BTLE devices using BPAV10 protocol
 */
@interface BPAV10Device : BPBTLEDevice

@end
