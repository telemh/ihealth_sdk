//
//  ECGHeader.h
//  iHealthDemoCode
//
//  Created by zhiwei jing on 16/7/12.
//  Copyright © 2016年 zhiwei jing. All rights reserved.
//

#ifndef ECGHeader_h
#define ECGHeader_h


#import "ECG3.h"
#import "ECG3Controller.h"
#import "ECGMacroFile.h"
#import "HealthUser.h"
#import "ECG3USB.h"
#import "ECG3USBController.h"

#endif /* ECGHeader_h */
