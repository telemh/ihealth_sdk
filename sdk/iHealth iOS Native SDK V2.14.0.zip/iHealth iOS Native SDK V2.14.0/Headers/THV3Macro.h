//
//  THV3Macro.h
//  iHealthDemoCode
//
//  Created by Realank on 2016/12/26.
//  Copyright © 2016年 zhiwei jing. All rights reserved.
//

#ifndef THV3Macro_h
#define THV3Macro_h
#import "THV3Controller.h"
#define THV3Discover        @"THV3Discover"
#define THV3ConnectFailed   @"THV3ConnectFailed"
#define THV3ConnectNoti @"THV3ConnectNoti"
#define THV3DisConnectNoti @"THV3DisConnectNoti"
#define THV3_NEW_DATA @"THV3NewDataCome"
#endif /* THV3Macro_h */
