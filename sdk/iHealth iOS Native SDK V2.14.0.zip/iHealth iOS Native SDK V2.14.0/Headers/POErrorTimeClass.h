//
//  POErrorTimeClass.h
//
//
//  Created by user on 2017/6/8.
//  Copyright © 2017年 user. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface POErrorTimeClass : NSObject
+(NSDictionary *)getDateRight;
+(NSDictionary *)getDateWrong;
@end
