//
//  TS28BHeader.h
//  iHealthSDKStatic
//
//  Created by Lei Bao on 2017/6/13.
//  Copyright © 2017年 daiqingquan. All rights reserved.
//

#ifndef TS28BHeader_h
#define TS28BHeader_h

#import "TS28B.h"
#import "TS28BController.h"

#endif /* TS28BHeader_h */
