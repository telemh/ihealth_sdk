//
//  BPBTLEDevice.h
//  iHealthSDKStatic
//
//  Created by Realank on 2017/9/22.
//  Copyright © 2017年 ihealthSDK. All rights reserved.
//

#import "BPDevice.h"


/**
 a subclass of BP device, which represent BP BTLE devices
 */
@interface BPBTLEDevice : BPDevice

@end
