## iHealth-ios-sdk-example

The demo of iHealth SDK can be obtained from the link below. If you have any questions, please submit Issues in the demo.

Link:https://github.com/iHealthLab/iHealth-ios-sdk-example


## iHealth-ios-sdk-docs


Link:https://chenxuewei-ihealth.github.io/ihealthlabs-sdk-docs

For all the devices supported by the SDK and the API descriptions used by all iHealth devices, you can view them from the link below.
